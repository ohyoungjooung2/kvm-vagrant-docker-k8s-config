mysql -u root -pStrongPass$^^$<<EOF
          CREATE USER 'replication_user'@'%' IDENTIFIED BY 'bigs3cret';
          GRANT REPLICATION SLAVE ON *.* TO 'replication_user'@'%';
EOF
